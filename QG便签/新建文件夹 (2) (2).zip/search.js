var searchLogo = document.getElementById('search_item'); //获取搜索图标
var searchInput = document.getElementById('search_input'); //获取搜索框
searchLogo.onclick = function() {
    var titleContent = document.querySelectorAll('.message_content'); //获取每一个小li里的标题
    console.log('123');
    console.log(titleContent.length);
    var searchVal = searchInput.value; //要查找得字符串

    for (var i = 0; i < titleContent.length; i++) {
        var text = titleContent[i].innerHTML;
        console.log(titleContent[i].innerHTML);

        text = text.replace(/<b[^>]*>([^>]*)<\/b[^>]*>/ig, "$1"); //把符合条件的替换成$1 我认为这一段没有问题
        titleContent[i].innerHTML = text;

        var reg = new RegExp("(" + searchVal + ")", "ig");
        text = text.replace(reg, "<b>$1</b>");
        titleContent[i].innerHTML = text;
    }
}